Kudos goes to Ilija Boshkov for building this package of CEED for Windows.

You need Microsoft Visual Studio 2013 runtime, get it here:
http://www.microsoft.com/en-us/download/details.aspx?id=40784