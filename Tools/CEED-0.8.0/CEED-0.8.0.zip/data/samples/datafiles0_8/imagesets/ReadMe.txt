The images in this directory were obtained from various sources...

SpaceBackground.jpg		    - Image Credit: NASA/JPL-Caltech (http://www.nasa.gov/multimedia/imagegallery/iotd.html)
Aliasing.jpg                - Aliasing test image created by Lukas "Ident" Meindl.
TaharezLook.tga			    - Original Taharez imagery created by Lars "Taharez" Rinde.
WindowsLook.tga			    - Windows look imagery created by Paul "CrazyEddie" Turner.
vanilla.tga			    	- Original "Vanilla GUI" imagery created by Shane Parker, used with permission.
HUDDemo.png                 - Interface graphics created by "syg". Food objects created by Lukas "Ident" Meindl, images mostly taken from http://openclipart.org/ and edited.
GameMenu.png                - Created and provided by "syg". Modified by Lukas "Ident" Meindl
BackgroundSampleBrowser.jpg - Taken from NASA images http://nssdc.gsfc.nasa.gov/photo_gallery/photogallery-mars.html